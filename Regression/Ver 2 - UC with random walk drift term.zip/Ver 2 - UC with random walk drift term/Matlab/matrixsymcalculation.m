syms a b c d

aa = [a,0,0,b;
     0,0,0,0;
     0,0,0,0;
     c,0,0,d];

bb= aa*aa.';
bb
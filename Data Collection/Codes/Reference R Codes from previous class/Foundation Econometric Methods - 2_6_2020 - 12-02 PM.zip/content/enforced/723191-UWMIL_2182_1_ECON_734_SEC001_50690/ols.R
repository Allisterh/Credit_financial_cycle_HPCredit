


rm(list=ls(all=TRUE))


# set directory
# check you have the right file path!!
filepath <- 'c:/734/prg'
setwd(filepath)



# load AER package 
library(AER)



##############################################################################
# simulate simple example
# set seed
set.seed(1)

# set up
nobs <- 25 
beta1 <- 2; beta2 <- 3

# simulate data
x <- rnorm(nobs)
e <- rnorm(nobs)
y <- beta1 + beta2*x + e

# true line
plot(c(-2,2),c(-4,6),type="n",xlab ="x",ylab="y")
abline(a=beta1,b=beta2,lwd=2,col="blue")

# true line + sample
plot(x,y,,xlim=c(-2,2),ylim=c(-4,6),xlab ="x",ylab="y")
abline(a=beta1,b=beta2,lwd=2,col="blue")

# simple regression: y on x
model0 <- lm(y~x)
summary(model0)

# true line + sample + sample regression
plot(x,y,,xlim=c(-2,2),ylim=c(-4,6),xlab ="x",ylab="y")
abline(a=beta1,b=beta2,lwd=2,col="blue")
abline(model0)

# plot residuals
plot(resid(model0))
abline(h=0)


##############################################################################
# empirical example
# load data (wages1.dat from Verbeek)
DATA <- read.table("wages1.dat",header=TRUE)
DATA[1:5,]

# summary statistics
summary(DATA)

# histogram of wage
par(mfrow=c(1,1))
hist(DATA$WAGE,breaks=16,main=NULL,col="blue")

# histogram of log(wage)
hist(log(DATA$WAGE),breaks=16,main=NULL,col="blue")

# scatterplot of log(wage) vs school 
plot(DATA$SCHOOL,log(DATA$WAGE))


# simple regression: log(wage) on school
model1 <- lm(log(WAGE)~log(SCHOOL),data=DATA)
summary(model1)

# plot regression
plot(log(DATA$SCHOOL),log(DATA$WAGE))
abline(model1)


# multiple regression

model2 <- lm(log(WAGE)~log(SCHOOL)+log(EXPER)+MALE,data=DATA)
summary(model2)
# residuals
ehat <- resid(model2)
# plot residuals
plot(ehat)
abline(h=0)
# histogram of residuals
hist(ehat,breaks=14,main=NULL,col="blue")


# print covariance matrix
print(vcov(model2))

# compute 95% confidence intervals
print(coef(model2))
confint(model2,level=.95)



# testing hypotheses

# test beta(exper)=.25
linearHypothesis(model2,"log(EXPER)=.25")

# test beta(log(exper)=.25 and beta(log(school)=1
linearHypothesis(model2,c("log(EXPER) =.25","log(SCHOOL) =1"))

# test 2*beta(log(exper)+1*beta(log(school)=1.5
linearHypothesis(model2,"2* log(EXPER) +1* log(SCHOOL) =.5")


# alternatively we can compare with model 1
anova(model1,model2)

# perform RESET test
resettest(model2,power=2:3)

model3 <- lm(log(WAGE)~log(SCHOOL)+I(log(SCHOOL)^2)+log(EXPER)+I(log(EXPER)^2)+MALE,data=DATA)
summary(model3)

# plot residuals vs fitted values
plot(fitted(model3),resid(model3))
abline(h=0)

# perform RESET test
resettest(model3,power=2:3)


# test the effect of schooling using F test
model4 <- lm(log(WAGE)~log(EXPER)+I(log(EXPER)^2)+MALE,data=DATA)
anova(model4,model3)

# test the effect of schooling using Wald test
waldtest(model3,c("log(SCHOOL)","I(log(SCHOOL)^2)"),test="Chisq")




# Chow test for male and female

# model for the full sample
model5 <- lm(log(WAGE)~log(SCHOOL)+log(EXPER),data=DATA)
# model for each subgroup
model6 <- lm(log(WAGE)~log(SCHOOL)+log(EXPER),data=DATA,subset=MALE=="0")
model7 <- lm(log(WAGE)~log(SCHOOL)+log(EXPER),data=DATA,subset=MALE=="1")

SSR.R <- deviance(model5)
SSR.U <- deviance(model6)+deviance(model7)
K <- length(coef(model5))
N <- length(resid(model5))

Fstat <- ((SSR.R-SSR.U)/K)/(SSR.U/(N-2*K))
pvalue <- 1-pf(Fstat,K,N-2*K)
print(c(Fstat,pvalue))


# alternatively
model8 <- lm(log(WAGE)~log(SCHOOL)+log(EXPER)+MALE+MALE*log(SCHOOL)+MALE*log(EXPER),data=DATA)
anova(model5,model8)



##############################################################################
# simulate distribution of estimator
# set seed
set.seed(1)

# number of observations in the simulated sample
nobs <- 100 
# number of simulations
nsim <- 1000

# simulate data
beta1 <- 1; beta2 <- 1
x <- c(rep(0,nobs/2),rep(1,nobs/2))

betas <- rep(0,nsim)
for(i in 1:nsim){ 
  # simulate data
  e <- rnorm(nobs)
  y <- beta1 + beta2*x + e
  # estimate model
  mod <- lm(y~x)
  # store estimated beta2
  betas[i] <- coef(mod)[2]
}

# plot empirical distribution
hist(betas,freq=FALSE,col="blue")
# plot asymptotic distribution
z <- seq(-4,4,length=1000)
p <- dnorm(z,mean=1,sd=sqrt(4/nobs))
lines(z,p,type="l",lwd=2)

# simulate distribution of estimator for different sample sizes
nobs <- c(30,100,300,500)
# plot asymptotic distribution
z <- seq(-4,4,length=1000)
p <- dnorm(z,mean=1,sd=sqrt(4/nobs[1]))
plot(z,p,type="l",lwd=2,xlim=c(-1,3),ylim=c(0,5))
for(i in 2:4){
  p <- dnorm(z,mean=1,sd=sqrt(4/nobs[i]))
  lines(z,p,type="l",lwd=2)
}


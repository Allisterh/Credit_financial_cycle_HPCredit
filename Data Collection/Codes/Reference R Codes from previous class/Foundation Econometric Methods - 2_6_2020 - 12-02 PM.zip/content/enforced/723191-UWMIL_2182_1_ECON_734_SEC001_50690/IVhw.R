
library(AER)
library(stargazer)
library(MASS)
library(robustbase)
library(foreign)
library(ivmodel)
library(lfe)
library(dplyr)

data <- read.csv("C:/Users/shrat/Desktop/T/734/IV/card1995.csv")
data<- select(data, age76, black, reg76r, smsa76r, nearc4a, nearc4b, ed76, lwage76, nearc4, nearc2)
data <- na.omit(data)

##a)


data$exper=data$age76-data$ed76-6
data$expersq=(data$exper*data$exper)/100

##LIML
Y=data[,"lwage76"]
D=data[,"ed76"]
Z=data[,c("nearc4a","nearc4b")]
X=data[,c("exper", "expersq", "black", "reg76r", "smsa76r")]
modelIV = ivmodel(Y=Y,D=D,Z=Z,X=X)
LIML(modelIV,alpha=0.01, heteroSE = TRUE)


##2SLS

tsls1 = ivreg(lwage76 ~ ed76+exper+expersq+black+reg76r+smsa76r | nearc4a+nearc4b+exper+expersq+black+reg76r+smsa76r, data=data)

summary(tsls1, vcov = sandwich, diagnostics = TRUE)


#confidence interval
confint(modelIV)


##b)
tsls2 = ivreg(lwage76 ~ ed76+exper+expersq+black+reg76r+smsa76r | nearc2+nearc4a+nearc4b+exper+expersq+black+reg76r+smsa76r, data=data)

summary(tsls2, vcov = sandwich, diagnostics = TRUE)

##c)

data$nearc4age=data$age76*data$nearc4
data$nearc4agesq=(data$nearc4age*data$nearc4age)/100

tsls3 = ivreg(lwage76 ~ ed76+exper+expersq+black+reg76r+smsa76r | nearc2+nearc4a+nearc4b+exper+expersq+black+reg76r+smsa76r+nearc4age+nearc4agesq, data=data)
summary(tsls3)



##d)
tsls3 = ivreg(lwage76 ~ ed76+exper+expersq+black+reg76r+smsa76r | nearc4age+nearc4agesq+nearc2+nearc4a+nearc4b+exper+expersq+black+reg76r+smsa76r, data=data)

summary(tsls3, vcov = sandwich, diagnostics = TRUE)


##d)
##1st stage
reg1 = lmrob(ed76 ~ exper+expersq+black+reg76r+smsa76r+nearc4age+nearc4agesq+nearc2+nearc4a+nearc4b+exper+expersq+black+reg76r+smsa76r, data=data)
summary(reg1)

##e)
attach(data)
fel<-felm(lwage76 ~ exper+expersq+black+reg76r+smsa76r | 0 | (ed76 ~ nearc4age+nearc4agesq+nearc2+nearc4a+nearc4b))

summary(fel)

condfstat(fel, type = "default", quantiles = 0, bN = 100L)

###f)
reg1<-lmrob(fel$iv.residuals ~ ed76)
summary(reg1)

###G)
Y=data[,"lwage76"]
D=data[,"ed76"]
Z=data[,c("nearc4a","nearc4b","nearc4age","nearc4agesq")]
X=data[,c("exper", "expersq", "black", "reg76r", "smsa76r")]
model2IV = ivmodel(Y=Y,D=D,Z=Z,X=X)
LIML(model2IV,alpha=0.01, heteroSE = TRUE)


###H)
confint(model2IV)












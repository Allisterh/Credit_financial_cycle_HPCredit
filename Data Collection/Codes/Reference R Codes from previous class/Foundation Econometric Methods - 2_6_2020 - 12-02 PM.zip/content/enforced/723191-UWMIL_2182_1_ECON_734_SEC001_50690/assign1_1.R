#Empirical Questions

################ Question 1
acs <- read.csv("C:/Users/shrat/Desktop/T/734/HW1/usa_00033.csv")
library(dummies)


summary(acs)

#drop all observations with missing data and the unemployed
acs <-subset(acs, acs$EMPSTAT<2 &  acs$WKSWORK2!=0 & acs$UHRSWORK!=0 & acs$AGE>24 & acs$AGE<51 &  acs$EDUC!=0 & acs$INCTOT<9999999 & acs$INCTOT>=0)

#Replace income=1 if it is 0
acs$INCTOT[acs$INCTOT < 1] <- 1

#Changing race to only 3 categories 
acs$RACE[acs$RACE > 3] <- 3

#Weeks worked
acs$WKSWORK2[acs$WKSWORK2 == 1] <- 13
acs$WKSWORK2[acs$WKSWORK2 == 2] <- 26
acs$WKSWORK2[acs$WKSWORK2 == 3] <- 39
acs$WKSWORK2[acs$WKSWORK2 == 4] <- 47
acs$WKSWORK2[acs$WKSWORK2 == 5] <- 49
acs$WKSWORK2[acs$WKSWORK2 == 6] <- 52

#education
acs$EDUC[acs$EDUC<6] <-0
acs$EDUC[acs$EDUC==6] <-1
acs$EDUC[acs$EDUC<10 & acs$EDUC>6] <-2
acs$EDUC[acs$EDUC>9]<-3

#drop all observations with missing data though there shouldnt be any at this point
acs <- na.omit(acs)

acs$hrswrkd<-acs$WKSWORK2*acs$UHRSWORK

acs$inchr<-acs$INCTOT/acs$hrswrkd

acs$linchr<-log(acs$inchr)

#Usually we might want to limit the data to get rid of outliers due to possibly misreported data
#here this could be mis-reported hours which is frequent in survey data, as the questions ask time worked since last interview

#acs <-subset(acs, acs$inchr<5000 & acs$inchr>7)

summary(acs)

acs$age2<-acs$AGE*acs$AGE

#There are a lot of dummies without labels here so we distingush them by using a seperator, you can also change the lables or the variables earlier when creating them
acs<- cbind(acs, dummy(acs$RACE, sep="_"), dummy(acs$SEX, sep="."), dummy(acs$EDUC, sep="__") )

#The baseline is white men with no high school education, so I exclude those dummies

reg<-lm (linchr ~ AGE + age2 + acs__1 + acs__2 + acs__3 + acs_2 + acs_3 + acs_2 + acs.2, data=acs)

coef(summary(reg))


#
X<- as.matrix(cbind(1 , acs$AGE , acs$age2 , acs$acs__1 , acs$acs__2 , acs$acs__3 , acs$acs_2 , acs$acs_3 , acs$acs.2))


Y<-as.matrix(acs$linchr)

tX<-t(X)

beta_hat <- solve(tX %*% X) %*% tX %*% Y

print(beta_hat)

#finding the residuals
res <- as.matrix(acs$linchr - X %*% beta_hat)
# Storing the number of observations and regressors
n<-nrow(Y)
k<-ncol(X)

#Finding the variance co-variance matrix
V<-1/(n-k) * as.numeric(t(res)%*%res) * solve(tX%*%X)

#the standard errors
se = sqrt(diag(V))

print(se)








############### Question 2
#######   a

#Putting together the data
cps <- read.csv("C:/Users/shrat/Desktop/T/734/HW1/cps09mar.csv")

cps$exp<-cps$age-cps$education-6

cps$exp2<-cps$exp*cps$exp

cps$wage<-cps$earnings/(cps$hours * cps$week)

#Creating X and Y for the regression

X<- as.matrix(cbind(1 , cps$exp , cps$exp2 , cps$education))

Y<-as.matrix(cps$wage)

tX<-t(X)

#Finding the coefficient

beta_hat <- solve(tX %*% X) %*% tX %*% Y

print(beta_hat)

#finding the residual

res <- as.matrix(cps$wage - X %*% beta_hat)

#sum of squared errors
#you can also just use matrix multiplication

rss <- sum((cps$wage - X %*% beta_hat)^2)

#R^2

r2<- 1-(sum((cps$wage - X %*% beta_hat)^2) /sum((cps$wage - mean(cps$wage))^2))




############       b
### FWLTheorem
# step 1 y on x1
X1<- as.matrix(cbind(1 , cps$exp , cps$exp2))


Y1<-as.matrix(cps$wage)

tX1<-t(X1)

beta_hat1 <- solve(tX1 %*% X1) %*% tX1 %*% Y1

res1 <- as.matrix(cps$wage - X1 %*% beta_hat1)

# step 2 x2 on x1
Y2<-as.matrix(cps$education)

beta_hat2 <- solve(tX1 %*% X1) %*% tX1 %*% Y2

res2 <- as.matrix(cps$education - X1 %*% beta_hat2)


# step 3 r1 on r2
X3<- as.matrix(res2)


Y3<-as.matrix(res1)

tX3<-t(X3)

beta_hat3 <- solve(tX3 %*% X3) %*% tX3 %*% Y3

print(beta_hat3)

##########   c
res3 <- as.matrix(res1 - res2 %*% beta_hat3)

rss3 <- sum((res1 - res2 %*% beta_hat3)^2)

r23<- 1-(sum((res1 - res2 %*% beta_hat3)^2) /sum((res1 - mean(res1))^2))



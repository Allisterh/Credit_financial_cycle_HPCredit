setwd("C:/734/prg")
library(gmm)
library(DataCombine)

rm(list = ls())
data =read.csv("cgg.csv",header=TRUE)

#Create Lagged values
data = slide(data, Var = "FFR", slideBy = -1)
data = slide(data, Var = "FFR", slideBy = -2)
data = slide(data, Var = "GAP", slideBy = -1)
data = slide(data, Var = "GAP", slideBy = -2)
data = slide(data, Var = "COM_P", slideBy = -1)
data = slide(data, Var = "COM_P", slideBy = -2)
data = slide(data, Var = "INFL", slideBy = -1)
data = slide(data, Var = "INFL", slideBy = -2)
data = slide(data, Var = "INFL", slideBy = +1)
data = slide(data, Var = "GAP", slideBy = +1)
data <- na.omit(data)

#1a
View(data)
infl_1=data[,16] #1-period ahead inflation
gap_1=data[,17]#1-period ahead output gap
int_1=data[,8]
int_2=data[,9]
y=data[,3]
h=data[,8:15] #instruments
g3 <- y~infl_1+gap_1+int_1+int_2

res=gmm(g3,x= cbind(data[,8],data[,9],data[,10],data[,11],data[,12],data[,13],data[,14],data[,15]))
summary(res)

coef_infl <- unname(res$coefficients[2])
coef_gap <- unname(res$coefficients[3])
coef_int1 <- unname(res$coefficients[4])
coef_int2 <- unname(res$coefficients[5])

rho <- coef_int1  + coef_int2    # interest rate persistence

beta <- coef_infl/(1-rho)
gamma <-coef_gap/(1-rho)     
c(beta, gamma, rho)#estimate for the full sample

#1b part 1
data1 = data[77:159,]
View(data1)

infl_12=data1[,16] #1-period ahead inflation
gap_12=data1[,17]#1-period ahead output gap
int_12=data1[,8]
int_22=data1[,9]
y2=data1[,3]
h2=data1[,8:15] #instruments
g32 <- y2~infl_12+gap_12+int_12+int_22

res2=gmm(g32,x= cbind(data1[,8],data1[,9],data1[,10],data1[,11],data1[,12],data1[,13],data1[,14],data1[,15]))

summary(res2)

coef_infl2 <- unname(res2$coefficients[2])
coef_gap2 <- unname(res2$coefficients[3])
coef_int12 <- unname(res2$coefficients[4])
coef_int22 <- unname(res2$coefficients[5])

rho2 <- coef_int12  + coef_int22    # interest rate persistence

beta2 <- coef_infl2/(1-rho2)
gamma2 <-coef_gap2/(1-rho2)     
c(beta2, gamma2, rho2)#estimate for the Vocker-GreenspaN period. Inflation response coefficient is much higher (2.67)

#1b part 2
data2 = data[1:76,]
View(data2)

infl_11=data2[,16] #1-period ahead inflation
gap_11=data2[,17]#1-period ahead output gap
int_11=data2[,8]
int_21=data2[,9]
y1=data2[,3]
h1=data2[,8:15] #instruments
g31 <- y1~infl_11+gap_11+int_11+int_21

res1=gmm(g31,x= cbind(data2[,8],data2[,9],data2[,10],data2[,11],data2[,12],data2[,13],data2[,14],data2[,15]))

summary(res1)

coef_infl1 <- unname(res1$coefficients[2])
coef_gap1 <- unname(res1$coefficients[3])
coef_int11 <- unname(res1$coefficients[4])
coef_int21 <- unname(res1$coefficients[5])

rho1 <- coef_int11  + coef_int21    # interest rate persistence

beta1 <- coef_infl1/(1-rho1)
gamma1 <-coef_gap1/(1-rho1)     
c(beta1, gamma1, rho1)#estimate for the Pre-Vocker period . Inflation response coefficient is lower (1.012)



#c if we change the list of instruments, the results change implying
#sensitivity of results to list of instruments
############# ASSIGNMENT 2

##########Question 1

#Setting up the sample
library(sm)
library(ggplot2)
library(dummies)
set.seed(3) 

alpha <- numeric(500) 
beta <- numeric(500)
gamma <-numeric(500)
a <- 1 
b <- -0.8
g <- 0.5
X.1 <- rnorm(1000, 1, 1)
plot(density(X.1))
X.2 <- runif(1000, min=0, max=10)
plot(density(X.2))

###### (a)
# Full model without an ommited variable
for(i in 1:500) {
Y <- a + b*X.1 + g*X.2 + rnorm(500, 0, 1) 
reg <- lm(Y~X.1 + X.2)
alpha[i] <- reg$coefficients[1]
beta[i] <- reg$coefficients[2]
gamma[i] <- reg$coefficients[3]
}
alpha1<-alpha
ap1<-density(alpha)
summary(alpha1)
plot(ap1)
beta1<-beta
bp1<-density(beta)
plot(bp1)
summary(beta1)
gamma1<-gamma
gp1<-density(gamma)
plot(gp1)
summary(gamma1)


######### (b)
#Ommited Variable 
for(i in 1:500) {
  Y <- a + b*X.1 + g*X.1 + rnorm(500, 0, 1) 
  reg <- lm(Y~X.2)
  alpha[i] <- reg$coefficients[1]
  beta[i] <- reg$coefficients[2]

}
alpha2<-alpha
ap2<-density(alpha)
plot(ap2)
beta2<-beta
bp2<-density(beta)
plot(bp2)

# Comparing the alpha and beta for the models
ap <- data.frame(alpha1, alpha2)
densa <- apply(ap, 2, density)
plot(NA, xlim=range(sapply(dens, "[", "x")), ylim=range(sapply(dens, "[", "y")))
mapply(lines, densa, col=1:length(densa))

bp <- data.frame(beta1, beta2)
densb <- apply(bp, 2, density)
plot(NA, xlim=range(sapply(densb, "[", "x")), ylim=range(sapply(densb, "[", "y")))
mapply(lines, densb, col=1:length(densb))

########### (c)
# additional variable

X.3 <- rnorm(1000, 10, 1)
plot(density(X.3))
for(i in 1:500) {
  Y <- a + b*X.1 + g*X.2 + rnorm(500, 0, 1) 
  reg <- lm(Y~X.1 + X.2 + X.3)
  alpha[i] <- reg$coefficients[1]
  beta[i] <- reg$coefficients[2]
  gamma[i] <- reg$coefficients[3]
}

ap<-density(alpha)
plot(ap)
alpha3<-alpha
bp<-density(beta)
plot(bp)
beta3<-beta
gp<-density(gamma)
plot(gp)
gamma3<-gamma

# Comparing the alpha, beta and gamma for the models
ap <- data.frame(alpha1, alpha3)
densa <- apply(ap, 2, density)
plot(NA, xlim=range(sapply(densa, "[", "x")), ylim=range(sapply(densa, "[", "y")))
mapply(lines, densa, col=1:length(densa))

bp <- data.frame(beta1, beta3)
densb <- apply(bp, 2, density)
plot(NA, xlim=range(sapply(densb, "[", "x")), ylim=range(sapply(densb, "[", "y")))
mapply(lines, densb, col=1:length(densb))

gp <- data.frame(gamma1, gamma3)
densg <- apply(gp, 2, density)
plot(NA, xlim=range(sapply(densg, "[", "x")), ylim=range(sapply(densg, "[", "y")))
mapply(lines, densg, col=1:length(densg))













########## 3
#Measurement error
#Setting up the sample
set.seed(9) 

alpha <- numeric(500) 
beta <- numeric(500)
se<-numeric(500)
a <- 0.2 
b <- 0.5
X.1 <- rnorm(1000, 2, 1)
plot(density(X.1))

###### (a)
# Full model without any measurement error
for(i in 1:500) {
  Y <- a + b*X.1 + rnorm(500, 0, 1) 
  reg <- lm(Y~X.1)
  alpha[i] <- reg$coefficients[1]
  beta[i] <- reg$coefficients[2]
}
alpha1<-alpha
ap1<-density(alpha)
summary(alpha1)
plot(ap1)
beta1<-beta
bp1<-density(beta)
plot(bp1)
summary(beta1)


# Measurement error for the dependent variable

for(i in 1:500) {
  Y <- a + b*X.1 + rnorm(500, 0, 1) 
  Ye <- Y + runif(500, 0, 1)
  model <- lm(Ye~X.1)
  alpha[i] <- model$coefficients[1]
  beta[i] <- model$coefficients[2]
}
alpha2<-alpha
ap2<-density(alpha)
summary(alpha2)
plot(ap2)
beta2<-beta
bp2<-density(beta)
plot(bp2)
summary(beta2)


# Measurement error for the independent variable

for(i in 1:500) {
  Y <- a + b*X.1 + rnorm(500, 0, 1) 
  Xe <- X.1 + runif(500, -3, 3)
  model <- lm(Y~Xe)
  alpha[i] <- model$coefficients[1]
  beta[i] <- model$coefficients[2]
}
alpha3<-alpha
ap3<-density(alpha)
summary(alpha3)
plot(ap3)
beta3<-beta
bp3<-density(beta)
plot(bp3)
summary(beta3)


# Comparing all three models
ap <- data.frame(alpha1, alpha2, alpha3)
densa <- apply(ap, 2, density)
plot(NA, xlim=range(sapply(densa, "[", "x")), ylim=range(sapply(densa, "[", "y")))
mapply(lines, densa, col=1:length(densa))

bp <- data.frame(beta1, beta2, beta3)
densb <- apply(bp, 2, density)
plot(NA, xlim=range(sapply(densb, "[", "x")), ylim=range(sapply(densb, "[", "y")))
mapply(lines, densb, col=1:length(densb))



########## 3
# Clustering

acs1 <- read.csv("C:/Users/shrat/Desktop/T/734/HW1/usa_00033.csv")
acs2 <- read.csv("C:/Users/shrat/Desktop/T/734/HW2/usa_00034.csv")

acs<- merge(acs1, acs2, by = c("SERIAL", "PERNUM"))

#drop all observations with missing data and the unemployed
acs <-subset(acs, acs$EMPSTAT<2 &  acs$WKSWORK2!=0 & acs$UHRSWORK!=0 & acs$AGE>24 & acs$AGE<51 &  acs$EDUC!=0 & acs$INCTOT<9999999 & acs$INCTOT>=0)

#Replace income=1 if it is 0
acs$INCTOT[acs$INCTOT < 1] <- 1

#Changing race to only 3 categories 
acs$RACE[acs$RACE > 3] <- 3

#Weeks worked
acs$WKSWORK2[acs$WKSWORK2 == 1] <- 13
acs$WKSWORK2[acs$WKSWORK2 == 2] <- 26
acs$WKSWORK2[acs$WKSWORK2 == 3] <- 39
acs$WKSWORK2[acs$WKSWORK2 == 4] <- 47
acs$WKSWORK2[acs$WKSWORK2 == 5] <- 49
acs$WKSWORK2[acs$WKSWORK2 == 6] <- 52

#education
acs$EDUC[acs$EDUC<6] <-0
acs$EDUC[acs$EDUC==6] <-1
acs$EDUC[acs$EDUC<10 & acs$EDUC>6] <-2
acs$EDUC[acs$EDUC>9]<-3

#drop all observations with missing data though there shouldnt be any at this point
acs <- na.omit(acs)

acs$hrswrkd<-acs$WKSWORK2*acs$UHRSWORK

acs$inchr<-acs$INCTOT/acs$hrswrkd

acs$linchr<-log(acs$inchr)

acs$age2<-acs$AGE*acs$AGE

acs<- cbind(acs, dummy(acs$RACE, sep="_"), dummy(acs$SEX, sep="."), dummy(acs$EDUC, sep="__") )

#reg<-lm (linchr ~ AGE + age2 + acs__1 + acs__2 + acs__3 + acs_2 + acs_3 + acs_2 + acs.2, data=acs)

#coef(summary(reg))

#regc<-lm.cluster(linchr ~ AGE + age2 + acs__1 + acs__2 + acs__3 + acs_2 + acs_3 + acs_2 + acs.2, data=acs, cluster="STATEFIP")

#coef(summary(regc))

X<- as.matrix(cbind(1 , acs$AGE , acs$age2 , acs$acs__1 , acs$acs__2 , acs$acs__3 , acs$acs_2 , acs$acs_3 , acs$acs.2))


Y<-as.matrix(acs$linchr)

tX<-t(X)

beta_hat <- solve(tX %*% X) %*% tX %*% Y

print(beta_hat)

fin<-data.frame

res <- as.matrix(acs$linchr - X %*% beta_hat)

n<-nrow(Y)
k<-ncol(X)

V<-1/(n-k) * as.numeric(t(res)%*%res) * solve(tX%*%X)

se = sqrt(diag(V))

print(se)

## Finding the clustered SE

state<-as.matrix(acs$STATEFIP)

xe<-X*rep(Y-X %*% beta_hat, times=k)

sxe<-rowsum(xe, state)

s<-nrow(sxe)

vc<-(s*(n-1)/((n-k)*(s-1)) * solve(tX %*% X) %*% t(sxe) %*% sxe %*% solve(tX %*% X))

sec<-sqrt(diag(vc))


fin<-data.frame(beta_hat, se, sec)

print(fin)
 
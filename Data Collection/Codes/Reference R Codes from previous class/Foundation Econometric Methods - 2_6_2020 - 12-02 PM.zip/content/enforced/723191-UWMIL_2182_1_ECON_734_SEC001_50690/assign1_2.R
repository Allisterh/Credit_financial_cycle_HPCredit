

setwd("c:/734/prg")
data<-read.csv("cps09mar.csv")

#    Regress log(Wage) on education, experience and experience^2
y<-as.matrix(log(data[,5]/(data[,6]*data[,7])))
exp<-data[,1]-data[,4]-6
exp2<-(exp^2)/100
edu<-data[,4]

model <- lm(y ~edu+exp+exp2 )

summary(model)

## second stage regression

## remove effect of experience and experience^2 from income

model1 <- lm(y ~exp+exp2 )

resid.model1 = resid(model1)

## remove effect of experience and experience^2  from  education

model2 <- lm(edu ~exp+exp2 )

resid.model2 = resid(model2)

## final regression of these two error using FWL

model3 <- lm(resid.model1 ~resid.model2-1)

summary(model3)





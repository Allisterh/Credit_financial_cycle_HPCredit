function f = ps1_exercise4

f = @(x) - x(1) * x(2) * x(3) ;
x0 = [ 5 5 5 ]' ; % the initial point
A = [ -1 -2 -2 ; 1 2 2 ] ; b = [ 0 72 ]' ;
sol = fmincon( f, x0, A, b ) ;
disp( sol )

end
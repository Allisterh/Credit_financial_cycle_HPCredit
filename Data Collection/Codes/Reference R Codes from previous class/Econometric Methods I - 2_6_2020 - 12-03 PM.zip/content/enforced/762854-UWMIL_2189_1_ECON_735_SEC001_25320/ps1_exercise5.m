clear
clc

n1 = 200;  %n1 = 1000;
rep = 1000;

X1 = rand(n1, rep) ; 
U1 = betarnd(2, 2, n1, rep) - 0.5 ; 
Y1 = exp(2*X1) - 2*X1.^3 + U1 ; 

ini1 = [ 1 -1 ]' ;
ini2 = [ 1 -1 1 ]' ;
ini3 = [ 1 0.5 -1 ]' ;

mse1 = zeros(rep,1); mse2 = zeros(rep,1); mse3 = zeros(rep,1); 
s1 = zeros(2, rep); s2 = zeros(3, rep); s3 = zeros(3, rep); 

for i = 1:rep
    
    x1 = X1(:, i);
    y1 = Y1(:, i);
         
    q1 = @(b) (y1 - exp(b(1) * x1) - b(2) * x1.^3 )' * (y1 - exp(b(1) * x1) - b(2) * x1.^3 ) ;
    q2 = @(b) (y1 - exp(b(1) * x1) - b(2) * x1.^3 - b(3) * x1.^2 )' * (y1 - exp(b(1) * x1) - b(2) * x1.^3 - b(3) * x1.^2 ) ;
    q3 = @(b) (y1 - exp(b(1) * x1 + b(2) * x1.^2) - b(3) * x1.^3 )' * (y1 - exp(b(1) * x1 + b(2) * x1.^2) - b(3) * x1.^3 ) ;
    
    s1(:,i) = fminsearch( q1, ini1 );
    s2(:,i) = fminsearch( q2, ini2 );
    s3(:,i) = fminsearch( q3, ini3 );
    
    f1 = @(x) ( exp( s1(1) * x ) + s1(2) * x.^3 - ( exp( 2 * x) - 2 * x.^3 ) ).^2 ;
    f2 = @(x) ( exp( s2(1) * x ) + s2(2) * x.^3 + s2(3) * x.^2 - ( exp( 2 * x) - 2 * x.^3 ) ).^2 ;
    f3 = @(x) ( exp( s3(1) * x + s3(2) * x.^2 ) + s3(3) * x.^3 - ( exp( 2 * x) - 2 * x.^3 ) ).^2 ;
    
    mse1(i,1) = sqrt ( integral(f1, 0, 1) ) ;
    mse2(i,1) = sqrt ( integral(f2, 0, 1) ) ;
    mse3(i,1) = sqrt ( integral(f3, 0, 1) ) ;        
    
end

disp( 'average estimates' )
disp( mean(s1,2) )
disp( mean(s2,2) )
disp( mean(s3,2) )

disp( 'root integrated squared error' )
disp( [ mean(mse1) mean(mse2) mean(mse3) ]' ) 
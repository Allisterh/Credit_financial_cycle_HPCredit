function ps1_example2

clc

f = @(x) x.^2 ;

ini = 8 ;

% sol = fmincon( f, ini, 1, -0.2, [], [], [], [], [] ) ;
% sol = fmincon( f, ini, 1, -0.5, [], [], [], [], [] ) ;
% sol = fmincon( f, ini, 1, -0.5, 3, -6, [], [], [] ) ;
% sol = fmincon( f, ini, 1, -0.5, 3, -15, [], [], [] ) ;
% sol = fmincon( f, ini, 1, -0.5, [], [], -3, -2, [] ) ;
% sol = fmincon( f, ini, 1, -0.5, [], [], -3, -0.2, [] ) ;
sol = fmincon( f, ini, 1, -0.2, [], [], -3, -0.2, @mycon ) ;

disp(sol)

end

% x = fmincon(fun, x0, A, b, Aeq, beq, lb, ub, nonlcon, options)

function [c, ceq] = mycon(x)

c = x.^3 - 0 ;
ceq = x.^2 - 1 ;

end

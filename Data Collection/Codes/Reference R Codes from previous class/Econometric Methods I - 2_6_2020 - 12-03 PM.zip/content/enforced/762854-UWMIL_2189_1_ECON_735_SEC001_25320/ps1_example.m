clear
clc

n = 200; % the number of sample n = 200, 1000
rep = 300; % 1000 random samples

X = rand(n, rep) ; %uniform distribution
U = normrnd(0, 3, n, rep) ;  
Y = log( 3 * X ) + 3 * X.^2 + U ;

ini1 = [ 2 2 ]' ;
ini2 = [ 2 2 2 ]' ;

ise1 = zeros(rep,1); ise2 = zeros(rep,1);
b1 = zeros(2, rep); b2 = zeros(3, rep);

for i = 1:rep
    
    x = X(:, i);
    y = Y(:, i);
         
    q1 = @(b) ( y - log (b(1) * x) - b(2) * x.^2 )' * ( y - log (b(1) * x) - b(2) * x.^2 ) ;
    
    q2 = @(b) ( y - log (b(1) * x) - b(2) * x.^2 - b(3) * x.^4 )' ...
                    * (y - log(b(1) * x) - b(2) * x.^2 - b(3) * x.^4 ) ;

    s1 = fminsearch( q1, ini1 );
    s2 = fminsearch( q2, ini2 );
    
    b1(:,i) = s1;
    b2(:,i) = s2;
   
    f1 = @(x) ( log( s1(1) * x ) + s1(2) * x.^2 - ( log ( 3 * x ) + 3 * x.^2 ) ).^2 ;
    f2 = @(x) ( log( s2(1) * x ) + s2(2) * x.^2 + s2(3) * x.^4 - ( log( 3 * x ) + 3 * x.^2 ) ).^2 ;
     
    ise1(i,1) = sqrt ( integral(f1, 0, 1) ) ;
    ise2(i,1) = sqrt ( integral(f2, 0, 1) ) ;
        
end

disp( 'average estimates' )
disp( mean(b1,2) )
disp( mean(b2,2) )

disp( 'root integrated squared error' )
disp( [ mean(ise1) mean(ise2) ]' ) 